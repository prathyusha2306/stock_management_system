package com.jfsfeb.stockmanagementsystemjdbc.service;

import com.jfsfeb.stockmanagementsystemjdbc.dto.DetailsOfStock;
import com.jfsfeb.stockmanagementsystemjdbc.dto.Investor;

public class InvestorServiceImple implements InvestorService {

	@Override
	public boolean registerInvestor(Investor investor) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean investorLogin(String emailId, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean changePassword(String emailId, String oldPassword, String newPassword) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean sellStock(int stockId) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean buyStock(DetailsOfStock stock) {
		// TODO Auto-generated method stub
		return false;
	}

	
	
}
