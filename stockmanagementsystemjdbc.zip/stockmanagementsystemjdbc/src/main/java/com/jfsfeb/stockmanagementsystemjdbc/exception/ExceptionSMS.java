package com.jfsfeb.stockmanagementsystemjdbc.exception;

@SuppressWarnings("serial")
public class ExceptionSMS extends RuntimeException {
	public ExceptionSMS(String msg) {
		super(msg);
}
}